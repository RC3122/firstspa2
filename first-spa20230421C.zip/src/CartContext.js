//創造Context
import { createContext } from "react";

export const CartContext = createContext() //export to share with other components
